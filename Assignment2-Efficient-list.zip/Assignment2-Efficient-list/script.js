document.addEventListener("DOMContentLoaded", () => {
    
    const list = document.getElementById("item-wrapper");
    const addItemButton = document.getElementById("add-item");
    const darkModeToggle = document.getElementById("dark-mode-toggle");
    const searchInput = document.getElementById("searchbar");
    const undoContainer = document.getElementById("undo-wrapper");
    const undoButton = document.getElementById("undo-btn");


    let items = [], itemCount = 0, lastRemoved = null, undoTimer = null;
    let dragSrcEl = null;

    loadItemsFromStorage();
    renderList();

    addItemButton.addEventListener("click", () => {
        addItems(4);
        saveItemsToStorage();
        renderList(searchInput.value.toLowerCase());
    });

    list.addEventListener("click", e => {
        if (e.target.classList.contains("list__button")) {
            const item = e.target.closest(".list__item");
            removeItem(item, item.firstChild.textContent.trim());
        }
    });

    list.addEventListener("dblclick", e => {
        const item = e.target.closest(".list__item");
        if (item && e.target === item) enableEditing(item);
    });

    darkModeToggle.addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");
        darkModeToggle.textContent = document.body.classList.contains("dark-mode") ? "Light Mode" : "Dark Mode";
    });

    searchInput.addEventListener("input", debounce(e => renderList(e.target.value.toLowerCase()), 300));

    undoButton.addEventListener("click", () => {
        if (!lastRemoved) return;
        items.splice(lastRemoved.index, 0, lastRemoved.text);
        saveItemsToStorage();
        renderList(searchInput.value.toLowerCase());
        lastRemoved = null;
        undoContainer.classList.add("hidden");
        clearTimeout(undoTimer);
    });

    function addItems(count) {
        for (let i = 0; i < count; i++) {
            itemCount++;
            const text = `Item ${itemCount}`;
            const index = Math.floor(Math.random() * (items.length + 1));
            items.splice(index, 0, text);
        }
    }

    function createListItem(text) {
        const li = document.createElement("li");
        li.className = "list__item px-3 bg-white my-1 items-center flex justify-between duration-300 ease-in-out";
        li.draggable = true;
        li.innerHTML = `${text} <button class="list__button duration-300 ease-in-out bg-red-800 hover:bg-red-700 text-white py-1 px-3 rounded m-2 cursor-move">Remove</button>`;

        li.addEventListener("dragstart", handleDragStart);
        li.addEventListener("dragover", e => e.preventDefault());
        li.addEventListener("drop", handleDrop);
        li.addEventListener("dragend", () => li.style.opacity = "1");

        return li;
    }

    function handleDragStart(e) {
        dragSrcEl = this;
        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("text/plain", this.firstChild.textContent.trim());
        this.style.opacity = "0.5";
    }

    function handleDrop(e) {
        e.preventDefault();
        if (this === dragSrcEl) return;

        const from = e.dataTransfer.getData("text/plain");
        const to = this.firstChild.textContent.trim();
        const fromIdx = items.indexOf(from);
        const toIdx = items.indexOf(to);

        if (fromIdx !== -1 && toIdx !== -1) {
            [items[fromIdx], items[toIdx]] = [items[toIdx], items[fromIdx]];
            saveItemsToStorage();
            renderList(searchInput.value.toLowerCase());
        }
    }

    function removeItem(item, text) {
        const removedItem = { text, index: items.indexOf(text) };
        item.classList.add("list__item--removing");

        setTimeout(() => {
            item.remove();
            items = items.filter(i => i !== text);
            saveItemsToStorage();
            renderList(searchInput.value.toLowerCase());
        }, 300);

        showUndo(removedItem);
    }

    function showUndo(removedItem) {
        lastRemoved = removedItem;
        undoContainer.classList.remove("hidden");

        clearTimeout(undoTimer);
        undoTimer = setTimeout(() => {
            undoContainer.classList.add("hidden");
            lastRemoved = null;
        }, 5000);
    }

    function enableEditing(item) {
        const oldText = item.firstChild.textContent.trim();
        const input = document.createElement("input");
        input.type = "text";
        input.value = oldText;
        input.className = "list__input w-[80%] p-2";

        item.firstChild.textContent = '';
        item.insertBefore(input, item.firstChild);

        input.focus();
        input.select();

        const finishEdit = () => saveEdit(item, input.value, oldText);
        input.addEventListener("keydown", e => e.key === "Enter" && finishEdit());
        input.addEventListener("blur", finishEdit);
    }

    function saveEdit(item, newText, oldText) {
        const button = item.querySelector(".list__button");
        item.innerHTML = `${newText} `;
        item.appendChild(button);

        const index = items.indexOf(oldText);
        if (index !== -1) {
            items[index] = newText;
            saveItemsToStorage();
            renderList(searchInput.value.toLowerCase());
        }
    }

    function saveItemsToStorage() {
        localStorage.setItem("ListItems", JSON.stringify(items));
    }

    function loadItemsFromStorage() {
        const stored = localStorage.getItem("ListItems");
        if (stored) {
            items = JSON.parse(stored);
            itemCount = items.length;
        }
    }

    function renderList(query = "") {
        list.innerHTML = "";
        const fragment = document.createDocumentFragment();
        items.forEach(text => {
            if (text.toLowerCase().includes(query)) {
                fragment.appendChild(createListItem(text));
            }
        });
        list.appendChild(fragment);
    }
});

function debounce(fn, delay) {
    let timer;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => fn.apply(this, args), delay);
    };
}
